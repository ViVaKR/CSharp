namespace MazeGame
{
    public partial class MainForm : Form
    {
        private readonly int[,] maze;
        private readonly bool[,] visited;
        private readonly Point[] directions;
        private readonly Panel panel;
        private const int size = 40;
        static readonly Random random = new(Guid.NewGuid().GetHashCode());

        public MainForm()
        {
            InitializeComponent();

            Padding = new Padding(100);
            StartPosition = FormStartPosition.CenterScreen;
            DoubleBuffered = true;
            Controls.Add(panel = new Panel { Dock = DockStyle.Fill });
            directions = new[] { new Point(1, 0), new Point(0, 1), new Point(-1, 0), new Point(0, -1) };

            visited = new bool[size, size];
            maze = new int[size, size];
            panel.Paint += Panel_Paint;
            InitiallizeMaze();
            panel.Invalidate();
            panel.Resize += (s, e) => panel.Invalidate();
            panel.BackColor = Color.Yellow;
            WindowState = FormWindowState.Maximized;
            Run();
        }

        private void Panel_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            for (int x = 0; x < size - 1; x++)
            {
                for (int y = 0; y < size - 1; y++)
                {
                    if (maze[x, y] == 1) g.FillRectangle(Brushes.Black, size * x, size * y, size, size);
                }
            }
        }

        private void InitiallizeMaze()
        {
            for (int x = 0; x < size; x++)
            {
                for (int y = 0; y < size; y++)
                {
                    visited[x, y] = false;
                    maze[x, y] = 1;
                }
            }
            panel.Invalidate();
        }

        private static List<T> ShuffleList<T>(List<T> t)
        {
            for (int i = 0; i < t.Count; i++)
            {
                int j = random.Next(i, t.Count);
                (t[j], t[i]) = (t[i], t[j]);
            }
            return t;
        }

        private bool ToBeOrNotToBeThatIsQnQ(int nextX, int nextY) =>
            nextX >= 0 && nextX < size - 1 && // (2)�캯��
            nextY >= 0 && nextY < size - 1 && // �º��� ����� 1�� ����
            !visited[nextX, nextY];

        private void GenerateMaze(int col, int row)
        {
            visited[col, row] = true;
            maze[col, row] = 0;
            List<int> directions = ShuffleList(new List<int> { 0, 1, 2, 3 });
            foreach (int direction in directions)
            {
                int nextCol = col + this.directions[direction].X * 2;
                int nextRow = row + this.directions[direction].Y * 2;
                if (ToBeOrNotToBeThatIsQnQ(nextCol, nextRow))
                {
                    var dx = col + this.directions[direction].X;
                    var dy = row + this.directions[direction].Y;
                    maze[dx, dy] = 0;
                    GenerateMaze(nextCol, nextRow);
                }
            }
        }

        // (1)���� ����Ʈ�� 0,0 ���� 1,1 �� ������
        private void Run() => GenerateMaze(1, 1);
    }
}