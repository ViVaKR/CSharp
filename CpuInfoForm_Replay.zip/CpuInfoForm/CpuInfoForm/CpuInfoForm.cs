using System.Text;
using System.Management;
using System.Runtime.Versioning;

namespace CpuInfoForm
{
    [SupportedOSPlatform("windows")]
    public partial class CpuInfoForm : Form
    {
        public CpuInfoForm()
        {
            InitializeComponent();

            Width = 1024;
            Height = 300;
            StartPosition = FormStartPosition.CenterScreen;

            Text = "CPU Information";


            Load += (s, e) =>
            {
                string? cpuInfo = GetCPUInfo();

                var label = new Label
                {
                    Dock = DockStyle.Fill,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Font = new Font(Font.FontFamily, 13.0f, FontStyle.Bold),
                    Text = $"CPU: {cpuInfo ?? "-"}",
                    ForeColor = Color.DarkKhaki
                };
                Controls.Add(label);
            };
        }

        private static string? GetCPUInfo()
        {
            ManagementScope? scope = new($@"\\{Environment.MachineName}\root\cimv2");
            scope.Connect();

            var query = new SelectQuery("SELECT * FROM Win32_Processor");
            StringBuilder? sb = new();

            using (ManagementObjectSearcher searcher = new(scope, query))
            {
                foreach (ManagementObject obj in searcher.Get().Cast<ManagementObject>())
                {
                    if (string.IsNullOrEmpty((string?)obj["Name"])) continue;
                    sb.Append(obj["Name"]);
                }
            }
            return sb?.ToString() ?? string.Empty;
        }
    }
}