﻿
namespace ToolStripProj
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UpButton_1 = new System.Windows.Forms.Button();
            this.UpButton_2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SaveButton = new System.Windows.Forms.Button();
            this.DownButton_1 = new System.Windows.Forms.Button();
            this.DownButton_2 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // UpButton_1
            // 
            this.UpButton_1.Dock = System.Windows.Forms.DockStyle.Right;
            this.UpButton_1.Location = new System.Drawing.Point(694, 39);
            this.UpButton_1.Name = "UpButton_1";
            this.UpButton_1.Size = new System.Drawing.Size(146, 41);
            this.UpButton_1.TabIndex = 3;
            this.UpButton_1.Text = "UP";
            this.UpButton_1.UseVisualStyleBackColor = true;
            this.UpButton_1.Click += new System.EventHandler(this.UpButton_1_Click);
            // 
            // UpButton_2
            // 
            this.UpButton_2.Dock = System.Windows.Forms.DockStyle.Right;
            this.UpButton_2.Location = new System.Drawing.Point(694, 39);
            this.UpButton_2.Name = "UpButton_2";
            this.UpButton_2.Size = new System.Drawing.Size(146, 41);
            this.UpButton_2.TabIndex = 4;
            this.UpButton_2.Text = "UP";
            this.UpButton_2.UseVisualStyleBackColor = true;
            this.UpButton_2.Click += new System.EventHandler(this.UpButton_2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.DownButton_1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.UpButton_1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(843, 83);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Text 1";
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(691, 41);
            this.label1.TabIndex = 4;
            this.label1.Text = "0";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.DownButton_2);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.UpButton_2);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 83);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(843, 83);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Text 2";
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(691, 41);
            this.label2.TabIndex = 5;
            this.label2.Text = "0";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.SaveButton);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox3.Location = new System.Drawing.Point(0, 224);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(843, 83);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "배열 상태";
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(545, 41);
            this.label3.TabIndex = 5;
            this.label3.Text = "0";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SaveButton
            // 
            this.SaveButton.Dock = System.Windows.Forms.DockStyle.Right;
            this.SaveButton.Location = new System.Drawing.Point(548, 39);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(292, 41);
            this.SaveButton.TabIndex = 4;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // DownButton_1
            // 
            this.DownButton_1.Dock = System.Windows.Forms.DockStyle.Right;
            this.DownButton_1.Location = new System.Drawing.Point(548, 39);
            this.DownButton_1.Name = "DownButton_1";
            this.DownButton_1.Size = new System.Drawing.Size(146, 41);
            this.DownButton_1.TabIndex = 5;
            this.DownButton_1.Text = "Down";
            this.DownButton_1.UseVisualStyleBackColor = true;
            this.DownButton_1.Click += new System.EventHandler(this.DownButton_1_Click);
            // 
            // DownButton_2
            // 
            this.DownButton_2.Dock = System.Windows.Forms.DockStyle.Right;
            this.DownButton_2.Location = new System.Drawing.Point(548, 39);
            this.DownButton_2.Name = "DownButton_2";
            this.DownButton_2.Size = new System.Drawing.Size(146, 41);
            this.DownButton_2.TabIndex = 6;
            this.DownButton_2.Text = "Down";
            this.DownButton_2.UseVisualStyleBackColor = true;
            this.DownButton_2.Click += new System.EventHandler(this.DownButton_2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 307);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("IBM Plex Sans KR", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button UpButton_1;
        private System.Windows.Forms.Button UpButton_2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button DownButton_1;
        private System.Windows.Forms.Button DownButton_2;
    }
}

