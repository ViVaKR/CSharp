﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace ToolStripProj
{
    public partial class Form1 : Form
    {
        private string[] numbers;

        /// <summary>
        /// 프로퍼티를 통한 값 변경 바인딩
        /// 텍스트 박스 => 라벨로 변경
        /// </summary>
        public string[] Numbers
        {
            get => numbers;
            set
            {
                if (value != null)
                {
                    numbers = value;
                    label1.Text = $"{Numbers[1]}";
                    label2.Text = $"{Numbers[2]}";
                    label3.Text = $"{string.Join(", ", Numbers)}";
                }
            }
        }

        private readonly string contents;
        
        private readonly string file;

        public Form1()
        {
            InitializeComponent();

            Width = 900;
            Height = 400;
            StartPosition = FormStartPosition.CenterScreen;
            
            // 대상 텍스트 파일 (screw.txt)의 내용
            contents = "1, 2, 3";

            // 바탕화면에 생성 -> `screw.txt` 파일 
            file = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "screw.txt");

            // 파일 정보 가져오기
            FileInfo fi = new FileInfo(file);

            // 바탕화면에 `screw.txt` 파일이 없다면 생성하고 내용(contents)을 기재
            if(!fi.Exists)
            {
                // 파일 만들기, 붙잡고 있으므로 꼭 Dispose() 해주기 필수
                // 안해주면 쓰질 못함..
                fi.Create().Dispose();

                // 파일에 내용 쓰기 (contents)
                File.WriteAllText(fi.FullName, contents, Encoding.UTF8);
            }

            // 파일내용 읽기, Encoding 필수
            var text = File.ReadAllText(file, Encoding.UTF8);

            // 읽은 내용 배열로 만든 후 공백이 있다면 공백을 모두 Trim 하기
            Numbers = text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
        }

        /// <summary>
        /// 값1 더하기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpButton_1_Click(object sender, EventArgs e)
        {
            int num1 = Convert.ToInt32(Numbers[1]);
            Numbers = new string[] { Numbers[0], $"{num1 + 1}", Numbers[2] };
        }

        /// <summary>
        /// 값2 더하기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpButton_2_Click(object sender, EventArgs e)
        {
            int num2 = Convert.ToInt32(Numbers[2]);
            Numbers = new string[] { Numbers[0], Numbers[1], $"{num2 + 1}" };
        }

        /// <summary>
        /// 현재 변경된 값을 파일 (screw.txt) 에 저장하여
        /// 프로그램을 다시 로드 할 때 그 값 부터 시작하기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveButton_Click(object sender, EventArgs e)
        {
            File.WriteAllText(file, string.Join(", ", Numbers), Encoding.UTF8);
        }

        /// <summary>
        /// 값1 빼기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DownButton_1_Click(object sender, EventArgs e)
        {
            int num1 = Convert.ToInt32(Numbers[1]);
            Numbers = new string[] { Numbers[0], $"{num1 - 1}", Numbers[2] };
        }

        /// <summary>
        /// 값2 빼기
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DownButton_2_Click(object sender, EventArgs e)
        {
            int num2 = Convert.ToInt32(Numbers[2]);
            Numbers = new string[] { Numbers[0], Numbers[1], $"{num2 - 1}" };
        }
    }
}
